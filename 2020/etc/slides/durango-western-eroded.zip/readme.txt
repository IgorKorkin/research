
Durango Western (Regular and Eroded)
Dennis Ludlow 2017 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Howdy font fans! Searching for an authentic looking Western font? Designing a WANTED poster? Well Durango Western is the new sheriff in town. This all caps display font is defined by its close spacing and thick serifs for a recognizable appearance. Use it for a movie poster, social media, or team logo.

Basic/Extended Latin, European accents, punctuation, diacritics, kerning, and Cyrillic characters for Russian are included in the full version. The eroded version features 2 levels of distress between the uppercase/lowercase, contains a few alternates, and features less punctuation. Please check the glyph maps. The regular version does not contain alternates. Uppercase and lowercase are identical. The demo contains basic Latin and numbers only. The full version can be acquired for $25 for personal use only or purchase of a commercial license. Please visit www.sharkshock.net/license for info on commercial use. Please note that this 25$ does not constitute a license of any kind.

This font may be freely redistributed as long as this readme file stays intact. Please contact me with any questions at dennis@sharkshock.net.

Tags: western, eroded, distressed, wild, west, cowboys, wanted, poster, project, scrapbook, logo, movie, poster, publishing, display, font, all, caps, serif, magazine, style, old, antique, grunge, Cyrillic, Russian, European, Europe, diacritics.

visit www.sharkshock.net for more and take a bite out of BORING design!
